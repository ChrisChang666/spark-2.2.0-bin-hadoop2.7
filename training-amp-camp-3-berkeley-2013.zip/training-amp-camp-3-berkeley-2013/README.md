AMPLab training materials.

All documenents related to all AMPCamps are in the directory called "ampcamp".
