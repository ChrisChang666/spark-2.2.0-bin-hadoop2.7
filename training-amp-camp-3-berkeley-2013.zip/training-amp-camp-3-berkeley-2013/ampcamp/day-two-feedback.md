---
layout: global
title: Feedback for Day 2
navigation:
  weight: 105
  show: true
skip-chapter-toc: true
---

<iframe src="https://docs.google.com/forms/d/1UZpTa_BX1lS8TxtRlIrfm4TJHkwtI7NGyZiQllQ6_H4/viewform?embedded=true" width="100%" height="800" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe>
